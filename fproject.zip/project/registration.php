<?php
require('db.php');
session_start();

if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $email = stripslashes($_POST['email']);
    $email = mysqli_real_escape_string($con, $email);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);

    // Check if the username or email already exists in the database
    $checkQuery = "SELECT * FROM `users` WHERE username='$username' OR email='$email'";
    $checkResult = mysqli_query($con, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        // Username or email already exists
        // Redirect to the sign-in form
        header("Location: registration.php");
        exit;
    } else {
        // Register the new user
        $create_datetime = date("Y-m-d H:i:s");

        // SQL INSERT statement to add a new user to the database
        $query = "INSERT into `users` (username, password, email, create_datetime) VALUES ('$username', '" . md5($password) . "', '$email', '$create_datetime')";
        $result = mysqli_query($con, $query);

        if ($result) {
            // Registration successful, redirect to the sign-in form
            header("Location: registration.php");
            exit;
        } else {
            // Redirect to the sign-in form with an error message
            header("Location: registration.php?error=registration_failed");
            exit;
        }
    }
} elseif (isset($_POST['username']) && isset($_POST['password'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);

    $query = "SELECT * FROM `users` WHERE username='$username' AND password='" . md5($password) . "'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        if ($row['username'] === 'admin') {
            // Admin login
            $_SESSION['username'] = $username;
            $_SESSION['is_admin'] = true; // Set an admin flag
            header("Location: main.php");
            exit;
        } else {
            // Regular user login
            $_SESSION['username'] = $username;
            header("Location: userpage.php");
            exit;
        }
    } else {
        // Redirect to the sign-in form with an error message
        header("Location: registration.php?error=login_failed");
        exit;
    }
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Lily Bead - Registration & Login</title>
    <link rel="stylesheet" type="text/css" href="./test1.css" />
    <script
        src="https://kit.fontawesome.com/64d58efce2.js"
        crossorigin="anonymous"
    ></script>
</head>
<body>
<div class="container">
    <div class="forms-container">
        <div class="signin-signup">
            <form action="registration.php" method="post" class="sign-in-form">
                <h2 class="title">Sign In</h2>
                <div class="input-field">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" placeholder="Username" required />
                </div>
                <div class="input-field">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Password" required />
                </div>
                <input type="submit" value="Login" class="btn solid" />
                <p class="social-text">Or Sign in with social platforms</p>
                <div class="social-media">
                    <a href='#' class='social-icon'>
                        <i class='fab fa-facebook-f'></i>
                    </a>
                    <a href='#' class='social-icon'>
                        <i class='fab fa-twitter'></i>
                    </a>
                    <a href='#' class='social-icon'>
                        <i class='fab fa-google'></i>
                    </a>
                    <a href='#' class='social-icon'>
                        <i class='fab fa-linkedin-in'></i>
                    </a>
                </div>
                <?php
            if (isset($_GET['error'])) {
                $error = $_GET['error'];
                if ($error === "registration_failed") {
                    echo "<p class='error-msg'>Registration failed.</p>";
                } elseif ($error === "login_failed") {
                    echo "<p class='error-msg'>Incorrect Username/password.</p>";
                }
            }
            ?>
            </form>

            <form action="registration.php" method="post" class="sign-up-form">
                <h2 class="title">Sign Up</h2>
                <div class="input-field">
                    <i class="fas fa-user"></i>
                    <input type="text" name="username" placeholder="Username" required />
                </div>
                <div class="input-field">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="email" placeholder="Email" required />
                </div>
                <div class="input-field">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="password" placeholder="Password" required />
                </div>
                <input type="submit" value="Sign Up" class="btn solid" />
                <p class="social-text">Or Sign up with social platforms</p>
                <div class="social-media">
                    <a href='#' class='social-icon'>
                        <i class='fab fa-facebook-f'></i>
                    </a>
                    <a href='#' class='social-icon'>
                        <i class='fab fa-twitter'></i>
                    </a>
                    <a href='#' class='social-icon'>
                        <i class='fab fa-google'></i>
                    </a>
                    <a href='#' class='social-icon'>
                        <i class='fab fa-linkedin-in'></i>
                    </a>
                </div>
            </form>
        </div>
    </div>
    <div class="panels-container">
        <div class="panel left-panel">
            <div class="content">
                <h3>New here?</h3>
                <p>Sign up for free</p>
                <button class="btn transparent" id="sign-up-btn">Sign Up</button>
            </div>
            <img src="./img/log.svg" class="image" alt="">
        </div>
        <div class="panel right-panel">
            <div class="content">
                <h3>Lily Bead</h3>
                <p>Est. 2023</p>
                <button class="btn transparent" id="sign-in-btn">Sign In</button>
            </div>
            <img src="./img/register.svg" class="image" alt="">
        </div>
    </div>
</div>
<script src="./test2.js"></script>
</body>
</html>
<?php
}
?>
